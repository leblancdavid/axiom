"""Regression tests for task priority handling."""

import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from task_manager import TaskStore


SCRIPT = Path(__file__).resolve().with_name("task_manager.py")
CREATED_AT = "2026-01-01T00:00:00Z"


class PriorityTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.store = TaskStore(Path(self.directory.name) / "tasks.json")

    def cli(self, *args):
        result = subprocess.run(
            [sys.executable, str(SCRIPT), *args],
            cwd=self.directory.name,
            capture_output=True,
            text=True,
            check=True,
        )
        return json.loads(result.stdout)

    def test_critical_round_trip_and_high_filter(self):
        critical = self.cli("create", "--title", "Urgent", "--description", "Now",
                            "--priority", "CRITICAL")
        high = self.cli("create", "--title", "Important", "--description", "Soon",
                        "--priority", "HIGH")
        default = self.cli("create", "--title", "Routine", "--description", "Later")

        self.assertEqual(critical["priority"], "CRITICAL")
        self.assertEqual(default["priority"], "NORMAL")
        self.assertEqual({task.id: task.priority for task in self.store.load()}, {
            critical["id"]: "CRITICAL", high["id"]: "HIGH", default["id"]: "NORMAL",
        })
        self.assertEqual({task["id"] for task in self.cli("list")},
                         {critical["id"], high["id"], default["id"]})
        self.assertEqual([task["id"] for task in self.cli("list-high")], [high["id"]])

    def test_migration_preserves_existing_priorities(self):
        rows = [
            {"id": priority.lower(), "title": priority, "description": "",
             "status": "pending", "priority": priority, "created_at": CREATED_AT}
            for priority in ("LOW", "NORMAL", "HIGH")
        ]
        self.store.path.write_text(json.dumps({"schema_version": 2, "records": rows}),
                                   encoding="utf-8")

        self.assertEqual(self.cli("migrate"), {"migrated": 3})
        self.assertEqual({task.id: task.priority for task in self.store.load()},
                         {"low": "LOW", "normal": "NORMAL", "high": "HIGH"})
        self.assertEqual({task.due_date for task in self.store.load()}, {None})

    def test_legacy_migration_defaults_to_normal(self):
        row = {"id": "legacy", "title": "Old", "description": "",
               "status": "pending", "created_at": CREATED_AT}
        self.store.path.write_text(json.dumps([row]), encoding="utf-8")

        self.assertEqual(self.cli("migrate"), {"migrated": 1})
        self.assertEqual(self.store.load()[0].priority, "NORMAL")


if __name__ == "__main__":
    unittest.main()
