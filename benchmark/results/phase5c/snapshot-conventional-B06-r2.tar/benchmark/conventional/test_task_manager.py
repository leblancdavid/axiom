"""Regression tests for task priority, tags, source, and category handling."""

import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from task_manager import TaskStore


SCRIPT = Path(__file__).resolve().with_name("task_manager.py")
CREATED_AT = "2026-01-01T00:00:00Z"


class PriorityTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.store = TaskStore(Path(self.directory.name) / "tasks.json")

    def cli(self, *args):
        result = subprocess.run(
            [sys.executable, str(SCRIPT), *args],
            cwd=self.directory.name,
            capture_output=True,
            text=True,
            check=True,
        )
        return json.loads(result.stdout)

    def test_critical_round_trip_and_high_filter(self):
        critical = self.cli("create", "--title", "Urgent", "--description", "Now",
                            "--priority", "CRITICAL")
        high = self.cli("create", "--title", "Important", "--description", "Soon",
                        "--priority", "HIGH")
        default = self.cli("create", "--title", "Routine", "--description", "Later")

        self.assertEqual(critical["priority"], "CRITICAL")
        self.assertEqual(default["priority"], "NORMAL")
        self.assertEqual(default["tags"], [])
        self.assertEqual(default["source"], "")
        self.assertEqual(default["category"], "")
        self.assertEqual({task.id: task.priority for task in self.store.load()}, {
            critical["id"]: "CRITICAL", high["id"]: "HIGH", default["id"]: "NORMAL",
        })
        self.assertEqual({task["id"] for task in self.cli("list")},
                         {critical["id"], high["id"], default["id"]})
        self.assertEqual([task["id"] for task in self.cli("list-high")], [high["id"]])

    def test_migration_preserves_existing_priorities(self):
        rows = [
            {"id": priority.lower(), "title": priority, "description": "",
             "status": "pending", "priority": priority, "created_at": CREATED_AT}
            for priority in ("LOW", "NORMAL", "HIGH")
        ]
        self.store.path.write_text(json.dumps({"schema_version": 2, "records": rows}),
                                   encoding="utf-8")

        self.assertEqual(self.cli("migrate"), {"migrated": 3})
        self.assertEqual({task.id: task.priority for task in self.store.load()},
                         {"low": "LOW", "normal": "NORMAL", "high": "HIGH"})
        self.assertEqual({task.due_date for task in self.store.load()}, {None})
        self.assertEqual([task.tags for task in self.store.load()], [[], [], []])
        self.assertEqual([task.source for task in self.store.load()], ["", "", ""])
        self.assertEqual([task.category for task in self.store.load()], ["", "", ""])

    def test_legacy_migration_defaults_to_normal(self):
        row = {"id": "legacy", "title": "Old", "description": "",
               "status": "pending", "created_at": CREATED_AT}
        self.store.path.write_text(json.dumps([row]), encoding="utf-8")

        self.assertEqual(self.cli("migrate"), {"migrated": 1})
        self.assertEqual(self.store.load()[0].priority, "NORMAL")
        self.assertEqual(self.store.load()[0].tags, [])
        self.assertEqual(self.store.load()[0].source, "")
        self.assertEqual(self.store.load()[0].category, "")

    def test_tags_are_trimmed_ordered_and_case_sensitive(self):
        created = self.cli("create", "--title", "Tagged", "--description", "Test",
                           "--priority", "CRITICAL", "--tag", "  work  ",
                           "--tag", "Work", "--tag", "work", "--tag", "home ")
        expected = ["work", "Work", "home"]
        self.assertEqual(created["tags"], expected)
        self.assertEqual(self.store.load()[0].tags, expected)
        self.assertEqual(self.cli("list")[0]["tags"], expected)
        self.assertEqual(self.cli("complete", "--id", created["id"])["tags"], expected)
        self.assertEqual(self.cli("list")[0]["tags"], expected)

    def test_blank_tag_rejects_create_without_writing(self):
        existing = self.cli("create", "--title", "Existing", "--description", "Keep")
        before = self.store.path.read_bytes()
        result = subprocess.run(
            [sys.executable, str(SCRIPT), "create", "--title", "New", "--description", "No",
             "--tag", "valid", "--tag", " \t "],
            cwd=self.directory.name, capture_output=True, text=True,
        )
        self.assertEqual(result.returncode, 1)
        self.assertEqual(json.loads(result.stderr), {"error": "invalid_tag"})
        self.assertEqual(self.store.path.read_bytes(), before)
        self.assertEqual([task["id"] for task in self.cli("list")], [existing["id"]])

    def test_list_tag_matches_exactly_in_normal_order_including_completed(self):
        work = self.cli("create", "--title", "Work", "--description", "",
                        "--tag", "work", "--tag", "home")
        capitalized = self.cli("create", "--title", "Capitalized", "--description", "",
                               "--tag", "Work")
        completed = self.cli("create", "--title", "Completed", "--description", "",
                             "--tag", "work")
        self.cli("complete", "--id", completed["id"])
        before = self.store.path.read_bytes()

        expected = [task for task in self.cli("list") if "work" in task["tags"]]
        self.assertEqual(self.cli("list-tag", "--tag", "work"), expected)
        self.assertEqual({task["id"] for task in expected}, {work["id"], completed["id"]})
        self.assertEqual(self.cli("list-tag", "--tag", "Work")[0]["id"], capitalized["id"])
        self.assertEqual(self.cli("list-tag", "--tag", "missing"), [])
        self.assertEqual(self.cli("list-tag", "--tag", " work "), [])
        self.assertEqual(self.store.path.read_bytes(), before)

    def test_list_tag_rejects_blank_query_without_writing(self):
        self.cli("create", "--title", "Existing", "--description", "", "--tag", "work")
        before = self.store.path.read_bytes()
        for query in ("", " \t "):
            with self.subTest(query=query):
                result = subprocess.run(
                    [sys.executable, str(SCRIPT), "list-tag", "--tag", query],
                    cwd=self.directory.name, capture_output=True, text=True,
                )
                self.assertEqual(result.returncode, 1)
                self.assertEqual(json.loads(result.stderr), {"error": "invalid_tag"})
                self.assertEqual(self.store.path.read_bytes(), before)

    def test_list_status_filters_all_matches_in_normal_order_without_writing(self):
        self.assertEqual(self.cli("list-status", "--status", "pending"), [])
        self.assertFalse(self.store.path.exists())
        pending = self.cli("create", "--title", "Pending", "--description", "",
                           "--priority", "HIGH")
        completed = self.cli("create", "--title", "Completed", "--description", "",
                             "--priority", "LOW")
        other_pending = self.cli("create", "--title", "Also pending", "--description", "",
                                 "--priority", "CRITICAL")
        other_completed = self.cli("create", "--title", "Also completed", "--description", "",
                                   "--priority", "HIGH")
        self.assertEqual(self.cli("list-status", "--status", "completed"), [])
        self.cli("complete", "--id", completed["id"])
        self.cli("complete", "--id", other_completed["id"])
        self.store.save(list(reversed(self.store.load())))
        before = self.store.path.read_bytes()

        all_tasks = self.cli("list")
        for status, ids in (("pending", {pending["id"], other_pending["id"]}),
                            ("completed", {completed["id"], other_completed["id"]})):
            with self.subTest(status=status):
                expected = [task for task in all_tasks if task["status"] == status]
                self.assertEqual({task["id"] for task in expected}, ids)
                self.assertEqual(self.cli("list-status", "--status", status), expected)
                self.assertEqual(self.store.path.read_bytes(), before)

    def test_version_three_migration_adds_tags_without_changing_fields(self):
        row = {"id": "critical", "title": "Old", "description": "Retain",
               "status": "pending", "priority": "CRITICAL", "created_at": CREATED_AT,
               "due_date": "2026-02-01T00:00:00Z"}
        self.store.path.write_text(json.dumps({"schema_version": 3, "records": [row]}),
                                   encoding="utf-8")
        result = subprocess.run([sys.executable, str(SCRIPT), "list"],
                                cwd=self.directory.name, capture_output=True, text=True)
        self.assertEqual(result.returncode, 1)
        self.assertEqual(json.loads(result.stderr), {"error": "migration_required"})
        self.assertEqual(self.cli("migrate"), {"migrated": 1})
        self.assertEqual(self.cli("list"), [{**row, "tags": [], "source": "", "category": ""}])
        self.assertEqual(json.loads(self.store.path.read_text(encoding="utf-8"))["schema_version"], 6)

    def test_source_is_verbatim_across_create_list_complete_and_delete(self):
        source = " \t mixed Case  \n"
        created = self.cli("create", "--title", "From source", "--description", "Test",
                           "--priority", "HIGH", "--tag", "work",
                           "--due-date", "2020-01-01T00:00:00Z", "--source", source)
        self.assertEqual(created["source"], source)
        self.assertEqual(self.store.load()[0].source, source)
        for command in (("list",), ("list-high",), ("list-overdue",),
                        ("list-tag", "--tag", "work")):
            self.assertEqual(self.cli(*command)[0]["source"], source)
        self.assertEqual(self.cli("complete", "--id", created["id"])["source"], source)
        self.assertEqual(self.cli("list")[0]["source"], source)
        self.assertEqual(self.cli("delete", "--id", created["id"])["source"], source)

    def test_version_four_migration_retains_tags_and_defaults_source(self):
        row = {"id": "old", "title": "Old", "description": "", "status": "pending",
               "priority": "HIGH", "created_at": CREATED_AT, "due_date": None,
               "tags": ["work"]}
        self.store.path.write_text(json.dumps({"schema_version": 4, "records": [row]}),
                                   encoding="utf-8")
        self.assertEqual(self.cli("migrate"), {"migrated": 1})
        self.assertEqual(self.cli("list"), [{**row, "source": "", "category": ""}])
        self.assertEqual(self.cli("migrate"), {"migrated": 0})

    def test_category_create_and_exact_filter_include_completed(self):
        self.assertEqual(self.cli("list-category", "--category", ""), [])
        self.assertFalse(self.store.path.exists())
        uncategorized = self.cli("create", "--title", "None", "--description", "")
        explicit = self.cli("create", "--title", "Empty", "--description", "",
                            "--category", "")
        work = self.cli("create", "--title", "Work", "--description", "",
                        "--category", "  work  ")
        capitalized = self.cli("create", "--title", "Case", "--description", "",
                               "--category", "Work")
        self.assertEqual(work["category"], "work")
        self.assertEqual(capitalized["category"], "Work")
        self.assertEqual(uncategorized["category"], explicit["category"])
        self.assertEqual(uncategorized["category"], "")
        self.assertEqual(self.cli("complete", "--id", work["id"])["category"], "work")
        self.store.save(list(reversed(self.store.load())))
        before = self.store.path.read_bytes()
        all_tasks = self.cli("list")
        self.assertEqual({task["id"] for task in all_tasks},
                         {uncategorized["id"], explicit["id"], work["id"], capitalized["id"]})
        for query in ("", "work", "Work", " work ", "missing"):
            with self.subTest(query=query):
                self.assertEqual(self.cli("list-category", "--category", query),
                                 [task for task in all_tasks if task["category"] == query])
        self.assertEqual(self.store.path.read_bytes(), before)
        self.assertEqual(self.cli("delete", "--id", work["id"])["category"], "work")

    def test_whitespace_only_category_rejected_without_writing(self):
        self.cli("create", "--title", "Existing", "--description", "")
        before = self.store.path.read_bytes()
        result = subprocess.run(
            [sys.executable, str(SCRIPT), "create", "--title", "New",
             "--description", "", "--category", " \t "],
            cwd=self.directory.name, capture_output=True, text=True,
        )
        self.assertEqual(result.returncode, 1)
        self.assertEqual(json.loads(result.stderr), {"error": "invalid_category"})
        self.assertEqual(self.store.path.read_bytes(), before)

    def test_version_five_migration_defaults_category_and_retains_source(self):
        row = {"id": "old", "title": "Old", "description": "", "status": "pending",
               "priority": "HIGH", "created_at": CREATED_AT, "due_date": None,
               "tags": ["work"], "source": " Original "}
        self.store.path.write_text(json.dumps({"schema_version": 5, "records": [row]}),
                                   encoding="utf-8")
        self.assertEqual(self.cli("migrate"), {"migrated": 1})
        self.assertEqual(self.cli("list"), [{**row, "category": ""}])
        self.assertEqual(self.cli("list-category", "--category", ""),
                         [{**row, "category": ""}])
        self.assertEqual(self.cli("migrate"), {"migrated": 0})


if __name__ == "__main__":
    unittest.main()
