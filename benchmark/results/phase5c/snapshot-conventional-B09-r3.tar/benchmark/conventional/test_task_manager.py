"""Regression tests for task attributes, migration, and CLI behavior."""

import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from task_manager import TaskStore


SCRIPT = Path(__file__).resolve().with_name("task_manager.py")
CREATED_AT = "2026-01-01T00:00:00Z"


class PriorityTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.store = TaskStore(Path(self.directory.name) / "tasks.json")

    def cli(self, *args):
        result = subprocess.run(
            [sys.executable, str(SCRIPT), *args],
            cwd=self.directory.name,
            capture_output=True,
            text=True,
            check=True,
        )
        return json.loads(result.stdout)

    def test_critical_round_trip_and_high_filter(self):
        critical = self.cli("create", "--title", "Urgent", "--description", "Now",
                            "--priority", "CRITICAL")
        high = self.cli("create", "--title", "Important", "--description", "Soon",
                        "--priority", "HIGH")
        default = self.cli("create", "--title", "Routine", "--description", "Later")

        self.assertEqual(critical["priority"], "CRITICAL")
        self.assertEqual(default["priority"], "NORMAL")
        self.assertEqual(default["tags"], [])
        self.assertEqual(default["source"], "")
        self.assertEqual(default["category"], "")
        self.assertEqual(default["notes"], [])
        self.assertIs(default["archived"], False)
        self.assertEqual({task.id: task.priority for task in self.store.load()}, {
            critical["id"]: "CRITICAL", high["id"]: "HIGH", default["id"]: "NORMAL",
        })
        self.assertEqual({task["id"] for task in self.cli("list")},
                         {critical["id"], high["id"], default["id"]})
        self.assertEqual([task["id"] for task in self.cli("list-high")], [high["id"]])

    def test_migration_preserves_existing_priorities(self):
        rows = [
            {"id": priority.lower(), "title": priority, "description": "",
             "status": "pending", "priority": priority, "created_at": CREATED_AT}
            for priority in ("LOW", "NORMAL", "HIGH")
        ]
        self.store.path.write_text(json.dumps({"schema_version": 2, "records": rows}),
                                   encoding="utf-8")

        self.assertEqual(self.cli("migrate"), {"migrated": 3})
        self.assertEqual({task.id: task.priority for task in self.store.load()},
                         {"low": "LOW", "normal": "NORMAL", "high": "HIGH"})
        self.assertEqual({task.due_date for task in self.store.load()}, {None})
        self.assertEqual([task.tags for task in self.store.load()], [[], [], []])
        self.assertEqual([task.source for task in self.store.load()], ["", "", ""])
        self.assertEqual([task.category for task in self.store.load()], ["", "", ""])
        self.assertEqual([task.notes for task in self.store.load()], [[], [], []])
        self.assertEqual([task.archived for task in self.store.load()], [False, False, False])

    def test_legacy_migration_defaults_to_normal(self):
        row = {"id": "legacy", "title": "Old", "description": "",
               "status": "pending", "created_at": CREATED_AT}
        self.store.path.write_text(json.dumps([row]), encoding="utf-8")

        self.assertEqual(self.cli("migrate"), {"migrated": 1})
        self.assertEqual(self.store.load()[0].priority, "NORMAL")
        self.assertEqual(self.store.load()[0].tags, [])
        self.assertEqual(self.store.load()[0].source, "")
        self.assertEqual(self.store.load()[0].category, "")
        self.assertEqual(self.store.load()[0].notes, [])
        self.assertIs(self.store.load()[0].archived, False)

    def test_tags_are_trimmed_ordered_and_case_sensitive(self):
        created = self.cli("create", "--title", "Tagged", "--description", "Test",
                           "--priority", "CRITICAL", "--tag", "  work  ",
                           "--tag", "Work", "--tag", "work", "--tag", "home ")
        expected = ["work", "Work", "home"]
        self.assertEqual(created["tags"], expected)
        self.assertEqual(self.store.load()[0].tags, expected)
        self.assertEqual(self.cli("list")[0]["tags"], expected)
        self.assertEqual(self.cli("complete", "--id", created["id"])["tags"], expected)
        self.assertEqual(self.cli("list")[0]["tags"], expected)

    def test_blank_tag_rejects_create_without_writing(self):
        existing = self.cli("create", "--title", "Existing", "--description", "Keep")
        before = self.store.path.read_bytes()
        result = subprocess.run(
            [sys.executable, str(SCRIPT), "create", "--title", "New", "--description", "No",
             "--tag", "valid", "--tag", " \t "],
            cwd=self.directory.name, capture_output=True, text=True,
        )
        self.assertEqual(result.returncode, 1)
        self.assertEqual(json.loads(result.stderr), {"error": "invalid_tag"})
        self.assertEqual(self.store.path.read_bytes(), before)
        self.assertEqual([task["id"] for task in self.cli("list")], [existing["id"]])

    def test_list_tag_matches_exactly_in_normal_order_including_completed(self):
        work = self.cli("create", "--title", "Work", "--description", "",
                        "--tag", "work", "--tag", "home")
        capitalized = self.cli("create", "--title", "Capitalized", "--description", "",
                               "--tag", "Work")
        completed = self.cli("create", "--title", "Completed", "--description", "",
                             "--tag", "work")
        self.cli("complete", "--id", completed["id"])
        before = self.store.path.read_bytes()

        expected = [task for task in self.cli("list") if "work" in task["tags"]]
        self.assertEqual(self.cli("list-tag", "--tag", "work"), expected)
        self.assertEqual({task["id"] for task in expected}, {work["id"], completed["id"]})
        self.assertEqual(self.cli("list-tag", "--tag", "Work")[0]["id"], capitalized["id"])
        self.assertEqual(self.cli("list-tag", "--tag", "missing"), [])
        self.assertEqual(self.cli("list-tag", "--tag", " work "), [])
        self.assertEqual(self.store.path.read_bytes(), before)

    def test_list_tag_rejects_blank_query_without_writing(self):
        self.cli("create", "--title", "Existing", "--description", "", "--tag", "work")
        before = self.store.path.read_bytes()
        for query in ("", " \t "):
            with self.subTest(query=query):
                result = subprocess.run(
                    [sys.executable, str(SCRIPT), "list-tag", "--tag", query],
                    cwd=self.directory.name, capture_output=True, text=True,
                )
                self.assertEqual(result.returncode, 1)
                self.assertEqual(json.loads(result.stderr), {"error": "invalid_tag"})
                self.assertEqual(self.store.path.read_bytes(), before)

    def test_list_status_filters_all_matches_in_normal_order_without_writing(self):
        self.assertEqual(self.cli("list-status", "--status", "pending"), [])
        self.assertFalse(self.store.path.exists())
        pending = self.cli("create", "--title", "Pending", "--description", "",
                           "--priority", "HIGH")
        completed = self.cli("create", "--title", "Completed", "--description", "",
                             "--priority", "LOW")
        other_pending = self.cli("create", "--title", "Also pending", "--description", "",
                                 "--priority", "CRITICAL")
        other_completed = self.cli("create", "--title", "Also completed", "--description", "",
                                   "--priority", "HIGH")
        self.assertEqual(self.cli("list-status", "--status", "completed"), [])
        self.cli("complete", "--id", completed["id"])
        self.cli("complete", "--id", other_completed["id"])
        self.store.save(list(reversed(self.store.load())))
        before = self.store.path.read_bytes()

        all_tasks = self.cli("list")
        for status, ids in (("pending", {pending["id"], other_pending["id"]}),
                            ("completed", {completed["id"], other_completed["id"]})):
            with self.subTest(status=status):
                expected = [task for task in all_tasks if task["status"] == status]
                self.assertEqual({task["id"] for task in expected}, ids)
                self.assertEqual(self.cli("list-status", "--status", status), expected)
                self.assertEqual(self.store.path.read_bytes(), before)

    def test_version_three_migration_adds_tags_without_changing_fields(self):
        row = {"id": "critical", "title": "Old", "description": "Retain",
               "status": "pending", "priority": "CRITICAL", "created_at": CREATED_AT,
               "due_date": "2026-02-01T00:00:00Z"}
        self.store.path.write_text(json.dumps({"schema_version": 3, "records": [row]}),
                                   encoding="utf-8")
        result = subprocess.run([sys.executable, str(SCRIPT), "list"],
                                cwd=self.directory.name, capture_output=True, text=True)
        self.assertEqual(result.returncode, 1)
        self.assertEqual(json.loads(result.stderr), {"error": "migration_required"})
        self.assertEqual(self.cli("migrate"), {"migrated": 1})
        self.assertEqual(self.cli("list"), [{**row, "tags": [], "source": "", "category": "",
                                              "notes": [], "archived": False}])
        self.assertEqual(json.loads(self.store.path.read_text(encoding="utf-8"))["schema_version"], 8)

    def test_source_is_verbatim_across_create_list_complete_and_delete(self):
        source = " \t mixed Case  \n"
        created = self.cli("create", "--title", "From source", "--description", "Test",
                           "--priority", "HIGH", "--tag", "work",
                           "--due-date", "2020-01-01T00:00:00Z", "--source", source)
        self.assertEqual(created["source"], source)
        self.assertEqual(self.store.load()[0].source, source)
        for command in (("list",), ("list-high",), ("list-overdue",),
                        ("list-tag", "--tag", "work")):
            self.assertEqual(self.cli(*command)[0]["source"], source)
        self.assertEqual(self.cli("complete", "--id", created["id"])["source"], source)
        self.assertEqual(self.cli("list")[0]["source"], source)
        self.assertEqual(self.cli("delete", "--id", created["id"])["source"], source)

    def test_version_four_migration_retains_tags_and_defaults_source(self):
        row = {"id": "old", "title": "Old", "description": "", "status": "pending",
               "priority": "HIGH", "created_at": CREATED_AT, "due_date": None,
               "tags": ["work"]}
        self.store.path.write_text(json.dumps({"schema_version": 4, "records": [row]}),
                                   encoding="utf-8")
        self.assertEqual(self.cli("migrate"), {"migrated": 1})
        self.assertEqual(self.cli("list"), [{**row, "source": "", "category": "", "notes": [],
                                              "archived": False}])
        self.assertEqual(self.cli("migrate"), {"migrated": 0})

    def test_category_create_and_exact_filter_include_completed(self):
        self.assertEqual(self.cli("list-category", "--category", ""), [])
        self.assertFalse(self.store.path.exists())
        uncategorized = self.cli("create", "--title", "None", "--description", "")
        explicit = self.cli("create", "--title", "Empty", "--description", "",
                            "--category", "")
        work = self.cli("create", "--title", "Work", "--description", "",
                        "--category", "  work  ")
        capitalized = self.cli("create", "--title", "Case", "--description", "",
                               "--category", "Work")
        self.assertEqual(work["category"], "work")
        self.assertEqual(capitalized["category"], "Work")
        self.assertEqual(uncategorized["category"], explicit["category"])
        self.assertEqual(uncategorized["category"], "")
        self.assertEqual(self.cli("complete", "--id", work["id"])["category"], "work")
        self.store.save(list(reversed(self.store.load())))
        before = self.store.path.read_bytes()
        all_tasks = self.cli("list")
        self.assertEqual({task["id"] for task in all_tasks},
                         {uncategorized["id"], explicit["id"], work["id"], capitalized["id"]})
        for query in ("", "work", "Work", " work ", "missing"):
            with self.subTest(query=query):
                self.assertEqual(self.cli("list-category", "--category", query),
                                 [task for task in all_tasks if task["category"] == query])
        self.assertEqual(self.store.path.read_bytes(), before)
        self.assertEqual(self.cli("delete", "--id", work["id"])["category"], "work")

    def test_whitespace_only_category_rejected_without_writing(self):
        self.cli("create", "--title", "Existing", "--description", "")
        before = self.store.path.read_bytes()
        result = subprocess.run(
            [sys.executable, str(SCRIPT), "create", "--title", "New",
             "--description", "", "--category", " \t "],
            cwd=self.directory.name, capture_output=True, text=True,
        )
        self.assertEqual(result.returncode, 1)
        self.assertEqual(json.loads(result.stderr), {"error": "invalid_category"})
        self.assertEqual(self.store.path.read_bytes(), before)

    def test_version_five_migration_defaults_category_and_retains_source(self):
        row = {"id": "old", "title": "Old", "description": "", "status": "pending",
               "priority": "HIGH", "created_at": CREATED_AT, "due_date": None,
               "tags": ["work"], "source": " Original "}
        self.store.path.write_text(json.dumps({"schema_version": 5, "records": [row]}),
                                   encoding="utf-8")
        self.assertEqual(self.cli("migrate"), {"migrated": 1})
        self.assertEqual(self.cli("list"), [{**row, "category": "", "notes": [],
                                              "archived": False}])
        self.assertEqual(self.cli("list-category", "--category", ""),
                           [{**row, "category": "", "notes": [], "archived": False}])
        self.assertEqual(self.cli("migrate"), {"migrated": 0})

    def test_version_six_migration_adds_notes_and_preserves_category(self):
        row = {"id": "old", "title": "Old", "description": "Retain", "status": "completed",
               "priority": "HIGH", "created_at": CREATED_AT, "due_date": None,
               "tags": ["work"], "source": "Original", "category": "work"}
        self.store.path.write_text(json.dumps({"schema_version": 6, "records": [row]}),
                                   encoding="utf-8")
        self.assertEqual(self.cli("migrate"), {"migrated": 1})
        self.assertEqual(self.cli("list"), [{**row, "notes": [], "archived": False}])
        self.assertEqual(self.cli("migrate"), {"migrated": 0})

    def test_version_seven_migration_preserves_notes_and_status(self):
        rows = [
            {"id": status, "title": status, "description": "", "status": status,
             "priority": "HIGH", "created_at": CREATED_AT, "due_date": None,
             "tags": ["work"], "source": "original", "category": "work",
             "notes": ["first", "first"]}
            for status in ("pending", "completed")
        ]
        self.store.path.write_text(json.dumps({"schema_version": 7, "records": rows}),
                                   encoding="utf-8")
        self.assertEqual(self.cli("migrate"), {"migrated": 2})
        self.assertEqual(self.cli("list"),
                         [{**row, "archived": False} for row in sorted(rows, key=lambda r: (r["created_at"], r["id"]))])
        self.assertEqual(self.cli("list-archived"), [])
        self.assertEqual(self.cli("migrate"), {"migrated": 0})

    def test_archive_hides_both_statuses_from_all_regular_lists(self):
        pending = self.cli("create", "--title", "Pending", "--description", "",
                           "--priority", "HIGH", "--tag", "work", "--category", "work",
                           "--due-date", "2020-01-01T00:00:00Z")
        completed = self.cli("create", "--title", "Completed", "--description", "",
                             "--priority", "HIGH", "--tag", "work", "--category", "work",
                             "--due-date", "2020-01-01T00:00:00Z")
        remaining = self.cli("create", "--title", "Visible", "--description", "",
                             "--priority", "HIGH", "--tag", "work", "--category", "work",
                             "--due-date", "2020-01-01T00:00:00Z")
        self.cli("complete", "--id", completed["id"])
        self.assertEqual(self.cli("archive", "--id", pending["id"]),
                         {**pending, "archived": True})
        self.assertEqual(self.cli("archive", "--id", completed["id"]),
                         {**completed, "status": "completed", "archived": True})
        self.store.save(list(reversed(self.store.load())))
        before = self.store.path.read_bytes()
        archived = self.cli("list-archived")
        self.assertEqual(archived, sorted(archived, key=lambda t: (t["created_at"], t["id"])))
        self.assertEqual({task["id"] for task in archived}, {pending["id"], completed["id"]})
        for command in (("list",), ("list-high",), ("list-overdue",),
                        ("list-tag", "--tag", "work"),
                        ("list-status", "--status", "pending"),
                        ("list-status", "--status", "completed"),
                        ("list-category", "--category", "work")):
            with self.subTest(command=command):
                results = self.cli(*command)
                self.assertEqual([task["id"] for task in results],
                                 [] if command == ("list-status", "--status", "completed")
                                 else [remaining["id"]])
        self.assertEqual(self.store.path.read_bytes(), before)

    def test_repeated_archive_and_missing_id_do_not_write(self):
        created = self.cli("create", "--title", "Task", "--description", "")
        self.cli("archive", "--id", created["id"])
        before = self.store.path.read_bytes()
        for task_id, error in ((created["id"], "invalid_transition"),
                               ("missing", "task_not_found")):
            with self.subTest(task_id=task_id):
                result = subprocess.run(
                    [sys.executable, str(SCRIPT), "archive", "--id", task_id],
                    cwd=self.directory.name, capture_output=True, text=True,
                )
                self.assertEqual(result.returncode, 1)
                self.assertEqual(json.loads(result.stderr), {"error": error})
                self.assertEqual(self.store.path.read_bytes(), before)

    def test_archived_state_requires_boolean(self):
        self.cli("create", "--title", "Task", "--description", "")
        payload = json.loads(self.store.path.read_text(encoding="utf-8"))
        for invalid in (0, "false", None):
            with self.subTest(invalid=invalid):
                payload["records"][0]["archived"] = invalid
                self.store.path.write_text(json.dumps(payload), encoding="utf-8")
                result = subprocess.run([sys.executable, str(SCRIPT), "list"],
                                        cwd=self.directory.name, capture_output=True, text=True)
                self.assertEqual(result.returncode, 1)
                self.assertEqual(json.loads(result.stderr), {"error": "invalid_state"})

    def test_list_due_inclusive_pending_only_and_normal_order_without_writing(self):
        start = "2026-02-01T00:00:00Z"
        end = "2026-02-03T00:00:00Z"
        self.assertEqual(self.cli("list-due", "--start", start, "--end", end), [])
        self.assertFalse(self.store.path.exists())
        early = self.cli("create", "--title", "Early", "--description", "",
                         "--due-date", start)
        middle = self.cli("create", "--title", "Middle", "--description", "",
                          "--due-date", "2026-02-02T00:00:00Z")
        late = self.cli("create", "--title", "Late", "--description", "",
                        "--due-date", end)
        self.cli("create", "--title", "Before", "--description", "",
                 "--due-date", "2026-01-31T23:59:59Z")
        self.cli("create", "--title", "After", "--description", "",
                 "--due-date", "2026-02-03T00:00:01Z")
        self.cli("create", "--title", "Undated", "--description", "")
        completed = self.cli("create", "--title", "Completed", "--description", "",
                             "--due-date", start)
        archived = self.cli("create", "--title", "Archived", "--description", "",
                            "--due-date", end)
        self.cli("complete", "--id", completed["id"])
        self.cli("archive", "--id", archived["id"])
        tasks = self.store.load()
        for task in tasks:
            task.created_at = {early["id"]: "2026-01-03T00:00:00Z",
                               middle["id"]: "2026-01-01T00:00:00Z",
                               late["id"]: "2026-01-02T00:00:00Z"}.get(task.id, CREATED_AT)
        self.store.save(list(reversed(tasks)))
        original = self.store.path.read_bytes()

        self.assertEqual([task["id"] for task in self.cli("list-due", "--start", start,
                                                         "--end", end)],
                         [middle["id"], late["id"], early["id"]])
        self.assertEqual([task["id"] for task in self.cli("list-due", "--start", start,
                                                         "--end", start)], [early["id"]])
        self.assertEqual([task["id"] for task in self.cli("list-due", "--start", end,
                                                         "--end", end)], [late["id"]])
        self.assertEqual(self.store.path.read_bytes(), original)

    def test_list_due_invalid_window_and_timestamps_do_not_write(self):
        self.cli("create", "--title", "Existing", "--description", "")
        original = self.store.path.read_bytes()
        valid = "2026-02-01T00:00:00Z"
        for start, end, error in (
            ("2026-02-02T00:00:00Z", valid, "invalid_window"),
            ("not-a-date", valid, "invalid_due_date"),
            (valid, "not-a-date", "invalid_due_date"),
            ("2026-02-01T00:00:00+00:00", valid, "invalid_due_date"),
            (valid, "2026-02-02T00:00:00+01:00", "invalid_due_date"),
        ):
            with self.subTest(start=start, end=end):
                result = subprocess.run(
                    [sys.executable, str(SCRIPT), "list-due", "--start", start, "--end", end],
                    cwd=self.directory.name, capture_output=True, text=True,
                )
                self.assertEqual(result.returncode, 1)
                self.assertEqual(json.loads(result.stderr), {"error": error})
                self.assertEqual(self.store.path.read_bytes(), original)

    def test_append_note_trims_and_preserves_order_and_duplicates(self):
        created = self.cli("create", "--title", "Notes", "--description", "")
        for text, expected in (("  first  ", ["first"]),
                               ("second", ["first", "second"]),
                               (" first ", ["first", "second", "first"])):
            with self.subTest(text=text):
                updated = self.cli("append-note", "--id", created["id"], "--text", text)
                self.assertEqual(updated["notes"], expected)
                self.assertEqual(self.cli("list")[0]["notes"], expected)
        self.assertEqual(self.cli("complete", "--id", created["id"])["notes"], expected)
        self.assertEqual(self.cli("delete", "--id", created["id"])["notes"], expected)

    def test_blank_note_rejected_without_changing_task_or_file(self):
        created = self.cli("create", "--title", "Notes", "--description", "")
        self.cli("append-note", "--id", created["id"], "--text", "kept")
        before = self.store.path.read_bytes()
        for text in ("", " \t\n "):
            with self.subTest(text=text):
                result = subprocess.run(
                    [sys.executable, str(SCRIPT), "append-note", "--id", created["id"],
                     "--text", text],
                    cwd=self.directory.name, capture_output=True, text=True,
                )
                self.assertEqual(result.returncode, 1)
                self.assertEqual(json.loads(result.stderr), {"error": "invalid_note"})
                self.assertEqual(self.store.path.read_bytes(), before)
        self.assertEqual(self.cli("list")[0]["notes"], ["kept"])

    def test_append_note_missing_task_does_not_write(self):
        self.cli("create", "--title", "Existing", "--description", "")
        before = self.store.path.read_bytes()
        result = subprocess.run(
            [sys.executable, str(SCRIPT), "append-note", "--id", "missing", "--text", "note"],
            cwd=self.directory.name, capture_output=True, text=True,
        )
        self.assertEqual(result.returncode, 1)
        self.assertEqual(json.loads(result.stderr), {"error": "task_not_found"})
        self.assertEqual(self.store.path.read_bytes(), before)


if __name__ == "__main__":
    unittest.main()
