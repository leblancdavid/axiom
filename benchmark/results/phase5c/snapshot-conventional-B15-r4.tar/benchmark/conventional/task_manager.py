"""Conventional, source-maintained implementation of the benchmark task CLI."""

import argparse
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import sys
import tempfile
from uuid import uuid4


STORE = Path("tasks.json")
VERSION = 10
PRIORITIES = ("LOW", "NORMAL", "HIGH", "CRITICAL")
STATUSES = ("pending", "completed")


class TaskError(Exception):
    pass


def parse_utc(value):
    if not isinstance(value, str) or not value.endswith("Z"):
        raise ValueError("expected UTC timestamp")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError("invalid timestamp") from exc
    if parsed.tzinfo is None or parsed.utcoffset().total_seconds() != 0:
        raise ValueError("expected UTC timestamp")
    return parsed


@dataclass
class Task:
    id: str
    title: str
    description: str
    status: str
    priority: str
    created_at: str
    due_date: str | None
    tags: list[str]
    source: str
    category: str
    notes: list[str]
    archived: bool
    owner: str
    dependencies: list[str]

    @classmethod
    def from_record(cls, record):
        if not isinstance(record, dict) or set(record) != set(cls.__dataclass_fields__):
            raise TaskError("invalid_state")
        if (not isinstance(record["id"], str) or not record["id"].strip()
                or not isinstance(record["title"], str) or not record["title"].strip()
                 or not isinstance(record["description"], str)
                   or not isinstance(record["source"], str)
                   or not isinstance(record["category"], str)
                   or record["category"] != record["category"].strip()
                   or not isinstance(record["owner"], str)
                   or record["owner"] != record["owner"].strip()
                   or record["status"] not in STATUSES
                   or type(record["archived"]) is not bool
                 or record["priority"] not in PRIORITIES):
            raise TaskError("invalid_state")
        tags = record["tags"]
        if (not isinstance(tags, list)
                or any(not isinstance(tag, str) or not tag or tag != tag.strip() for tag in tags)
                or len(set(tags)) != len(tags)):
            raise TaskError("invalid_state")
        notes = record["notes"]
        if (not isinstance(notes, list)
                or any(not isinstance(note, str) or not note or note != note.strip()
                       for note in notes)):
            raise TaskError("invalid_state")
        dependencies = record["dependencies"]
        if (not isinstance(dependencies, list)
                or any(not isinstance(dep, str) or not dep or dep != dep.strip()
                       for dep in dependencies)
                or len(set(dependencies)) != len(dependencies)):
            raise TaskError("invalid_state")
        try:
            parse_utc(record["created_at"])
            if record["due_date"] is not None:
                parse_utc(record["due_date"])
        except ValueError as exc:
            raise TaskError("invalid_state") from exc
        return cls(**record)


class TaskStore:
    def __init__(self, path=STORE):
        self.path = Path(path)

    def _load_payload(self):
        try:
            with self.path.open(encoding="utf-8") as source:
                return json.load(source)
        except FileNotFoundError as exc:
            if self.path.exists():
                raise TaskError("persistence_failure") from exc
            return None
        except (json.JSONDecodeError, UnicodeError) as exc:
            raise TaskError("invalid_state") from exc
        except OSError as exc:
            raise TaskError("persistence_failure") from exc

    @staticmethod
    def _records(rows):
        if not isinstance(rows, list):
            raise TaskError("invalid_state")
        tasks = [Task.from_record(row) for row in rows]
        if len({task.id for task in tasks}) != len(tasks):
            raise TaskError("invalid_state")
        by_id = {task.id: task for task in tasks}
        dependents = {task.id: [] for task in tasks}
        remaining = {task.id: len(task.dependencies) for task in tasks}
        for task in tasks:
            for dependency in task.dependencies:
                if dependency not in by_id:
                    raise TaskError("invalid_state")
                dependents[dependency].append(task.id)
        ready = [task_id for task_id, count in remaining.items() if count == 0]
        processed = 0
        while ready:
            processed += 1
            for dependent in dependents[ready.pop()]:
                remaining[dependent] -= 1
                if remaining[dependent] == 0:
                    ready.append(dependent)
        if processed != len(tasks):
            raise TaskError("invalid_state")
        return tasks

    def load(self):
        payload = self._load_payload()
        if payload is None:
            return []
        if not isinstance(payload, dict) or payload.get("schema_version") != VERSION:
            raise TaskError("migration_required")
        if set(payload) != {"schema_version", "records"}:
            raise TaskError("invalid_state")
        return self._records(payload["records"])

    def save(self, tasks):
        self._records([asdict(task) for task in tasks])
        temporary = None
        try:
            with tempfile.NamedTemporaryFile(
                mode="w", encoding="utf-8", dir=self.path.parent,
                prefix=".tasks-", suffix=".tmp", delete=False,
            ) as dest:
                temporary = Path(dest.name)
                json.dump({"schema_version": VERSION, "records": [asdict(t) for t in tasks]},
                          dest, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
                dest.write("\n")
            os.replace(temporary, self.path)
        except OSError as exc:
            raise TaskError("persistence_failure") from exc
        finally:
            if temporary is not None:
                temporary.unlink(missing_ok=True)

    def migrate(self):
        payload = self._load_payload()
        if payload is None:
            return {"migrated": 0}
        if isinstance(payload, dict) and payload.get("schema_version") == VERSION:
            self.load()
            return {"migrated": 0}
        if isinstance(payload, list):
            version, rows = 1, payload
        elif isinstance(payload, dict) and payload.get("schema_version") in range(2, VERSION):
            if set(payload) != {"schema_version", "records"}:
                raise TaskError("invalid_state")
            version, rows = payload["schema_version"], payload["records"]
        else:
            raise TaskError("invalid_state")
        if not isinstance(rows, list):
            raise TaskError("invalid_state")
        fields = set(Task.__dataclass_fields__)
        missing = {"dependencies"}
        if version < 9:
            missing.add("owner")
        if version < 8:
            missing.add("archived")
        if version < 7:
            missing.add("notes")
        if version < 6:
            missing.add("category")
        if version < 5:
            missing.add("source")
        if version < 4:
            missing.add("tags")
        if version < 3:
            missing.add("due_date")
        if version < 2:
            missing.add("priority")
        migrated = []
        for row in rows:
            if not isinstance(row, dict) or set(row) != fields - missing:
                raise TaskError("invalid_state")
            migrated.append({**row, **({"priority": "NORMAL"} if version == 1 else {}),
                             **({"due_date": None} if version < 3 else {}),
                              **({"tags": []} if version < 4 else {}),
                               **({"source": ""} if version < 5 else {}),
                                **({"category": ""} if version < 6 else {}),
                                  **({"notes": []} if version < 7 else {}),
                                    **({"archived": False} if version < 8 else {}),
                                     **({"owner": ""} if version < 9 else {}),
                                     "dependencies": []})
        tasks = self._records(migrated)
        self.save(tasks)
        return {"migrated": len(tasks)}


class TaskService:
    def __init__(self, store):
        self.store = store

    @staticmethod
    def ordered(tasks):
        return sorted(tasks, key=lambda task: (task.created_at, task.id))

    def create(self, title, description, priority="NORMAL", due_date=None, tags=None,
               source="", category="", owner=None):
        tasks = self.store.load()
        if not title.strip():
            raise TaskError("invalid_title")
        if not isinstance(category, str) or (category and not category.strip()):
            raise TaskError("invalid_category")
        category = category.strip()
        if owner is not None:
            if not isinstance(owner, str) or not owner.strip():
                raise TaskError("invalid_owner")
            owner = owner.strip()
        else:
            owner = ""
        cleaned_tags = []
        for tag in tags if tags is not None else ():
            if not isinstance(tag, str) or not tag.strip():
                raise TaskError("invalid_tag")
            tag = tag.strip()
            if tag not in cleaned_tags:
                cleaned_tags.append(tag)
        if due_date is not None:
            try:
                parse_utc(due_date)
            except ValueError as exc:
                raise TaskError("invalid_due_date") from exc
        task = Task(str(uuid4()), title, description, "pending", priority,
                    datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"), due_date,
                       cleaned_tags, source, category, [], False, owner, [])
        if any(other.id == task.id for other in tasks):
            raise TaskError("id_collision")
        tasks.append(task)
        self.store.save(tasks)
        return task

    def list(self, mode, tag=None, status=None, category=None, start=None, end=None,
             owner=None):
        if mode == "list-tag" and (not isinstance(tag, str) or not tag.strip()):
            raise TaskError("invalid_tag")
        if mode == "list-due":
            try:
                start_time, end_time = parse_utc(start), parse_utc(end)
            except ValueError as exc:
                raise TaskError("invalid_due_date") from exc
            if start_time > end_time:
                raise TaskError("invalid_window")
        tasks = self.store.load()
        if mode == "list-archived":
            return self.ordered(task for task in tasks if task.archived)
        tasks = [task for task in tasks if not task.archived]
        if mode == "list-high":
            tasks = [task for task in tasks if task.priority == "HIGH"]
        elif mode in ("list-overdue", "list-urgent"):
            now = datetime.now(timezone.utc)
            tasks = [task for task in tasks if task.status == "pending" and task.due_date is not None
                     and parse_utc(task.due_date) < now
                     and (mode == "list-overdue" or task.priority in ("HIGH", "CRITICAL"))]
        elif mode == "list-due":
            tasks = [task for task in tasks if task.status == "pending" and task.due_date is not None
                     and start_time <= parse_utc(task.due_date) <= end_time]
        elif mode == "list-tag":
            tasks = [task for task in tasks if tag in task.tags]
        elif mode == "list-status":
            tasks = [task for task in tasks if task.status == status]
        elif mode == "list-category":
            tasks = [task for task in tasks if task.category == category]
        elif mode == "list-owner":
            tasks = [task for task in tasks if task.owner == owner]
        return self.ordered(tasks)

    def change(self, task_id, action):
        tasks = self.store.load()
        task = next((item for item in tasks if item.id == task_id), None)
        if task is None:
            raise TaskError("task_not_found")
        if action == "complete":
            if task.archived or task.status != "pending":
                raise TaskError("invalid_transition")
            by_id = {item.id: item for item in tasks}
            if any(by_id[dependency].status != "completed" for dependency in task.dependencies):
                raise TaskError("incomplete_dependencies")
            task.status = "completed"
        elif action == "archive":
            if task.archived:
                raise TaskError("invalid_transition")
            task.archived = True
        else:
            if any(task_id in other.dependencies for other in tasks):
                raise TaskError("dependency_in_use")
            if task.status == "completed" and not task.archived:
                raise TaskError("delete_requires_archive")
            tasks.remove(task)
        self.store.save(tasks)
        return task

    def add_dependency(self, task_id, depends_on):
        tasks = self.store.load()
        by_id = {task.id: task for task in tasks}
        if task_id not in by_id or depends_on not in by_id:
            raise TaskError("task_not_found")
        task = by_id[task_id]
        if task_id == depends_on or depends_on in task.dependencies:
            raise TaskError("invalid_dependency")

        def reaches(start, target):
            pending = [start]
            seen = set()
            while pending:
                current = pending.pop()
                if current == target:
                    return True
                if current not in seen:
                    seen.add(current)
                    pending.extend(by_id[current].dependencies)
            return False

        if reaches(depends_on, task_id):
            raise TaskError("invalid_dependency")
        task.dependencies.append(depends_on)
        self.store.save(tasks)
        return task

    def append_note(self, task_id, text):
        tasks = self.store.load()
        task = next((item for item in tasks if item.id == task_id), None)
        if task is None:
            raise TaskError("task_not_found")
        if task.archived:
            raise TaskError("invalid_transition")
        if not isinstance(text, str) or not text.strip():
            raise TaskError("invalid_note")
        task.notes.append(text.strip())
        self.store.save(tasks)
        return task


def main(argv=None):
    parser = argparse.ArgumentParser(prog="task_manager")
    commands = parser.add_subparsers(dest="command", required=True)
    create = commands.add_parser("create")
    create.add_argument("--title", required=True)
    create.add_argument("--description", required=True)
    create.add_argument("--priority", choices=PRIORITIES)
    create.add_argument("--due-date")
    create.add_argument("--tag", action="append", default=[])
    create.add_argument("--source", default="")
    create.add_argument("--category", default="")
    create.add_argument("--owner")
    for name in ("list", "list-high", "list-overdue", "list-urgent", "list-archived",
                 "migrate"):
        commands.add_parser(name)
    commands.add_parser("list-tag").add_argument("--tag", required=True)
    commands.add_parser("list-status").add_argument("--status", required=True, choices=STATUSES)
    commands.add_parser("list-category").add_argument("--category", required=True)
    commands.add_parser("list-owner").add_argument("--owner", required=True)
    list_due = commands.add_parser("list-due")
    list_due.add_argument("--start", required=True)
    list_due.add_argument("--end", required=True)
    for name in ("complete", "delete", "archive"):
        commands.add_parser(name).add_argument("--id", required=True)
    append_note = commands.add_parser("append-note")
    append_note.add_argument("--id", required=True)
    append_note.add_argument("--text", required=True)
    add_dependency = commands.add_parser("add-dependency")
    add_dependency.add_argument("--id", required=True)
    add_dependency.add_argument("--depends-on", required=True)
    args = parser.parse_args(argv)
    service = TaskService(TaskStore())
    try:
        if args.command == "create":
            result = service.create(args.title, args.description, args.priority or "NORMAL",
                                    args.due_date, args.tag, args.source, args.category, args.owner)
        elif args.command in ("list", "list-high", "list-overdue", "list-urgent",
                                "list-tag", "list-status",
                               "list-category", "list-owner", "list-archived", "list-due"):
            result = service.list(args.command, args.tag if args.command == "list-tag" else None,
                                   args.status if args.command == "list-status" else None,
                                   args.category if args.command == "list-category" else None,
                                   args.start if args.command == "list-due" else None,
                                    args.end if args.command == "list-due" else None,
                                    args.owner if args.command == "list-owner" else None)
        elif args.command == "migrate":
            result = service.store.migrate()
        elif args.command == "append-note":
            result = service.append_note(args.id, args.text)
        elif args.command == "add-dependency":
            result = service.add_dependency(args.id, args.depends_on)
        else:
            result = service.change(args.id, args.command)
    except TaskError as exc:
        print(json.dumps({"error": str(exc)}), file=sys.stderr)
        return 1
    if isinstance(result, list):
        result = [asdict(task) for task in result]
    elif isinstance(result, Task):
        result = asdict(result)
    print(json.dumps(result, sort_keys=True, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
